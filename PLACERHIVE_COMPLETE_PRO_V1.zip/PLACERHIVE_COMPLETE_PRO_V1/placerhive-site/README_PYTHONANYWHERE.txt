PLACERHIVE COMPLETE PROFESSIONAL PACKAGE
=======================================

This ZIP contains the complete Flask website: public frontend + private /admin control centre.
It does NOT contain the live SQLite database, so extracting it over your existing project will preserve the current database and jobs/users/payments.

WHAT IS INCLUDED
- Professional gold/charcoal responsive frontend
- Mobile navigation
- Live job search by keyword, location and category
- Job details and candidate applications
- Candidate accounts and application tracking
- Employer request flow with 30-minute payment window
- Payment proof submission and manual admin verification
- Private /admin login
- Admin job creation/editing, active/disabled state and exact role counts
- Admin user enable/disable
- Admin application status management
- Admin payment verification/rejection
- Admin logo upload
- Admin testimonials with image upload
- Admin registration/application/payment/maintenance controls
- Admin payment amount control
- Admin contact messages and newsletter subscribers

PYTHONANYWHERE INSTALL
1. Upload this ZIP to /home/placerhiver/
2. Open a Bash console and run:

   cd ~
   unzip -o PLACERHIVE_COMPLETE_PRO_V1.zip
   cd ~/placerhive-site

3. Do NOT delete placerhive.db. The package intentionally leaves the database alone.
4. If your existing virtualenv is already working, keep it. Otherwise:

   python3.10 -m venv venv
   source venv/bin/activate
   pip install -r requirements.txt

5. Web app Source code:
   /home/placerhiver/placerhive-site

6. Working directory:
   /home/placerhiver/placerhive-site

7. WSGI file:
   import sys
   path = '/home/placerhiver/placerhive-site'
   if path not in sys.path:
       sys.path.insert(0, path)
   from app import app as application

8. Reload the PythonAnywhere web app.
9. Open: https://placerhiver.pythonanywhere.com/
10. Admin: https://placerhiver.pythonanywhere.com/admin

ADMIN PASSWORD
Default password: placeplaceplace121212

IMPORTANT
- This package does not delete your old ZIP files.
- This package does not delete your SQLite database.
- Keep your existing backup ZIP/database until you have tested the new site.
- After deployment, test Home, Find Jobs, Seek a Job, Hire Talent, payment popup, signup/login and /admin.
