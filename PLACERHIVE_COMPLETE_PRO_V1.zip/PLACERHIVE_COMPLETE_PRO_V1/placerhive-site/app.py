import os
import sqlite3
import uuid
from datetime import datetime, timezone
from functools import wraps

from flask import Flask, render_template, request, jsonify, session, redirect, url_for, send_from_directory
from werkzeug.utils import secure_filename
from werkzeug.security import generate_password_hash, check_password_hash

BASE = os.path.dirname(os.path.abspath(__file__))
DB = os.path.join(BASE, 'placerhive.db')
# If the previous PythonAnywhere deployment had a database, preserve it automatically.
LEGACY_DB = os.path.expanduser('~/placerhive-site-backup/placerhive.db')
if not os.path.exists(DB) and os.path.exists(LEGACY_DB):
    import shutil
    shutil.copy2(LEGACY_DB, DB)
UPLOADS = os.path.join(BASE, 'uploads')
STATIC_IMAGES = os.path.join(BASE, 'static', 'images')
os.makedirs(UPLOADS, exist_ok=True)
os.makedirs(STATIC_IMAGES, exist_ok=True)

app = Flask(__name__)
app.secret_key = os.environ.get('SECRET_KEY', 'change-this-secret-key-before-launch')
app.config['MAX_CONTENT_LENGTH'] = 12 * 1024 * 1024
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'placeplaceplace121212')
PAYMENT_AMOUNT = os.environ.get('PAYMENT_AMOUNT', '299.00')
PAYMENT_DETAILS = {
    'Account Name': 'PETER GODSTIME EFERIDONO',
    'Bank': 'Lead Bank',
    'Account Number': '214175521736',
    'Routing Number': '101019644',
    'Account Type': 'Personal Checking',
    'Account Address': '9450 Southwest Gemini Drive, Beaverton, OR, 97008, USA'
}

DEFAULT_JOBS = [
    ('Senior Software Developer', 'USA', 'Software Development', 'Permanent', 12),
    ('Cyber Security Analyst', 'Canada', 'Cyber Security', 'Contract', 8),
    ('Financial Controller', 'Nigeria', 'Accounting & Finance', 'Permanent', 6),
    ('Civil Engineer', 'California', 'Engineering', 'Permanent', 10),
    ('HR Business Partner', 'Italy', 'Human Resources (HR)', 'Permanent', 5),
    ('IT Project Manager', 'Remote', 'IT Project & Change Management', 'Contract', 7),
    ('Marketing Manager', 'Brazil', 'Marketing & Digital', 'Permanent', 9),
    ('Facilities Manager', 'China', 'Property & Facilities Management', 'Permanent', 4),
    ('Sales Executive', 'Japan', 'Sales', 'Permanent', 15),
    ('Sustainability Consultant', 'USA', 'Sustainability', 'Contract', 5),
    ('Network Engineer', 'Cameroon', 'IT Infrastructure', 'Permanent', 7),
    ('Clinical Research Associate', 'Indonesia', 'Life Sciences', 'Contract', 4),
    ('Construction Project Manager', 'Nigeria', 'Construction', 'Permanent', 6),
    ('Data Scientist', 'Remote', 'Technology', 'Permanent', 8),
    ('Banking Relationship Manager', 'USA', 'Banking & Financial Services', 'Permanent', 5),
    ('Pharmaceutical Sales Rep', 'Canada', 'Pharmaceuticals', 'Permanent', 6),
    ('Renewable Energy Engineer', 'California', 'Alternative Energy & Renewables', 'Contract', 5),
    ('Media Account Executive', 'Italy', 'Media & Communications', 'Permanent', 7),
]


def now_iso():
    return datetime.now(timezone.utc).isoformat()


def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    conn.execute('PRAGMA foreign_keys = ON')
    return conn


def ensure_column(conn, table, column, definition):
    cols = {row['name'] for row in conn.execute(f'PRAGMA table_info({table})').fetchall()}
    if column not in cols:
        conn.execute(f'ALTER TABLE {table} ADD COLUMN {column} {definition}')


def init_db():
    conn = db()
    conn.executescript('''
    CREATE TABLE IF NOT EXISTS employer_submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        company_name TEXT NOT NULL,
        contact_name TEXT NOT NULL,
        job_title TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        website TEXT,
        country TEXT,
        company_size TEXT,
        hiring_needs TEXT NOT NULL,
        budget TEXT,
        created_at TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'awaiting_payment',
        payment_expires_at TEXT
    );
    CREATE TABLE IF NOT EXISTS payments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        submission_id INTEGER NOT NULL,
        transaction_ref TEXT NOT NULL,
        payer_name TEXT NOT NULL,
        proof_filename TEXT,
        submitted_at TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'pending',
        admin_note TEXT,
        verified_at TEXT,
        expires_at TEXT,
        FOREIGN KEY(submission_id) REFERENCES employer_submissions(id)
    );
    CREATE TABLE IF NOT EXISTS job_applications (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        full_name TEXT,
        email TEXT,
        phone TEXT,
        location TEXT,
        job_title TEXT,
        specialism TEXT,
        experience TEXT,
        job_type TEXT,
        summary TEXT,
        cv_filename TEXT,
        photo_filename TEXT,
        created_at TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'new'
    );
    CREATE TABLE IF NOT EXISTS jobs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        location TEXT NOT NULL,
        category TEXT NOT NULL,
        job_type TEXT NOT NULL,
        available_roles INTEGER NOT NULL DEFAULT 0,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        updated_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS site_settings (
        key TEXT PRIMARY KEY,
        value TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS contact_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT,
        subject TEXT,
        message TEXT NOT NULL,
        created_at TEXT NOT NULL,
        status TEXT NOT NULL DEFAULT 'new'
    );
    CREATE TABLE IF NOT EXISTS newsletter_subscribers (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        email TEXT UNIQUE NOT NULL,
        created_at TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        full_name TEXT NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        phone TEXT,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL,
        last_login TEXT
    );
    CREATE TABLE IF NOT EXISTS testimonials (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL,
        role TEXT,
        rating INTEGER NOT NULL DEFAULT 5,
        quote TEXT NOT NULL,
        image_filename TEXT,
        is_active INTEGER NOT NULL DEFAULT 1,
        created_at TEXT NOT NULL
    );
    ''')

    # Migrate older databases created by the first PythonAnywhere package.
    ensure_column(conn, 'job_applications', 'user_id', 'INTEGER')
    ensure_column(conn, 'job_applications', 'location', 'TEXT')
    ensure_column(conn, 'job_applications', 'job_title', 'TEXT')
    ensure_column(conn, 'job_applications', 'specialism', 'TEXT')
    ensure_column(conn, 'job_applications', 'experience', 'TEXT')
    ensure_column(conn, 'job_applications', 'job_type', 'TEXT')
    ensure_column(conn, 'job_applications', 'summary', 'TEXT')
    ensure_column(conn, 'job_applications', 'cv_filename', 'TEXT')
    ensure_column(conn, 'job_applications', 'photo_filename', 'TEXT')
    ensure_column(conn, 'payments', 'expires_at', 'TEXT')
    ensure_column(conn, 'employer_submissions', 'payment_expires_at', 'TEXT')

    if conn.execute('SELECT COUNT(*) FROM jobs').fetchone()[0] == 0:
        for title, location, category, job_type, count in DEFAULT_JOBS:
            conn.execute('''INSERT INTO jobs(title,location,category,job_type,available_roles,is_active,created_at,updated_at)
                            VALUES(?,?,?,?,?,?,?,?)''',
                         (title, location, category, job_type, count, 1, now_iso(), now_iso()))

    default_settings = {
        'payment_amount': PAYMENT_AMOUNT,
        'site_logo': '/static/images/placerhive-logo.svg',
        'registration_enabled': '1',
        'applications_enabled': '1',
        'payments_enabled': '1',
        'maintenance_mode': '0',
    }
    for key, value in default_settings.items():
        if conn.execute('SELECT 1 FROM site_settings WHERE key=?', (key,)).fetchone() is None:
            conn.execute('INSERT INTO site_settings(key,value) VALUES(?,?)', (key, value))
    if conn.execute('SELECT COUNT(*) FROM testimonials').fetchone()[0] == 0:
        samples = [
            ('Sample Candidate', 'Software Professional', 5, 'This is a sample review. Replace it with a verified PLACERHIVE user review from the admin panel.'),
            ('Sample Employer', 'Hiring Manager', 5, 'Sample employer feedback. Add verified customer stories and photos from the admin panel before publishing.'),
            ('Sample Job Seeker', 'Marketing Professional', 4, 'Sample review for layout purposes. Replace with an authentic testimonial when available.'),
        ]
        for name, role, rating, quote in samples:
            conn.execute('INSERT INTO testimonials(name,role,rating,quote,created_at) VALUES(?,?,?,?,?)', (name,role,rating,quote,now_iso()))
    conn.commit()
    conn.close()


def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not session.get('admin_logged_in'):
            return jsonify({'ok': False, 'error': 'Admin login required'}), 401
        return fn(*args, **kwargs)
    return wrapper


@app.before_request
def maintenance_guard():
    if request.path.startswith('/static') or request.path.startswith('/api/admin') or request.path == '/admin': return None
    if site_setting('maintenance_mode','0') == '1' and not session.get('admin_logged_in'):
        return render_template('message.html', title='Site maintenance', message='PLACERHIVE is temporarily unavailable while the administrator makes updates.'), 503
    return None

@app.context_processor
def globals_for_templates():
    return {'payment_amount': current_payment_amount(), 'payment_details': PAYMENT_DETAILS, 'site_logo': site_setting('site_logo'), 'current_user': current_user()}


def site_setting(key, default=''):
    try:
        conn = db(); row = conn.execute('SELECT value FROM site_settings WHERE key=?', (key,)).fetchone(); conn.close()
        return row['value'] if row else default
    except Exception:
        return default

def current_user():
    uid = session.get('user_id')
    if not uid: return None
    try:
        conn=db(); row=conn.execute('SELECT id,full_name,email,phone,is_active FROM users WHERE id=?',(uid,)).fetchone(); conn.close()
        if row and row['is_active']: return dict(row)
    except Exception:
        pass
    return None

def user_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not current_user(): return redirect(url_for('login', next=request.path))
        return fn(*args, **kwargs)
    return wrapper

def current_payment_amount():
    try:
        conn = db()
        row = conn.execute("SELECT value FROM site_settings WHERE key='payment_amount'").fetchone()
        conn.close()
        return row['value'] if row else PAYMENT_AMOUNT
    except Exception:
        return PAYMENT_AMOUNT


@app.route('/')
def home():
    conn = db()
    featured_jobs = conn.execute("SELECT id,title,location,category,job_type,available_roles FROM jobs WHERE is_active=1 AND available_roles>0 ORDER BY id DESC LIMIT 6").fetchall()
    total_roles = conn.execute("SELECT COALESCE(SUM(available_roles),0) FROM jobs WHERE is_active=1").fetchone()[0]
    testimonials = conn.execute("SELECT * FROM testimonials WHERE is_active=1 ORDER BY id DESC LIMIT 6").fetchall()
    conn.close()
    return render_template('index.html', featured_jobs=[dict(r) for r in featured_jobs], total_roles=total_roles, testimonials=[dict(r) for r in testimonials])


@app.route('/jobs')
def jobs():
    return render_template('jobs.html')

@app.route('/job/<int:job_id>')
def job_detail(job_id):
    conn=db(); row=conn.execute('SELECT * FROM jobs WHERE id=? AND is_active=1',(job_id,)).fetchone(); conn.close()
    if not row or row['available_roles']<=0: return render_template('not-found.html'),404
    return render_template('job-detail.html', job=dict(row))

@app.route('/about')
def about():
    return redirect(url_for('home')+'#about')

@app.route('/contact')
def contact():
    return redirect(url_for('home')+'#contact')


@app.route('/seek-a-job')
def seek_job():
    return render_template('seek-a-job.html')


@app.route('/employer')
@app.route('/employer-bass')
def employer():
    return render_template('employer.html')


@app.route('/payment')
def payment():
    sid = request.args.get('submission_id', '')
    return render_template('payment.html', submission_id=sid)


@app.route('/payment-pending')
def payment_pending():
    return render_template('payment-pending.html')

@app.route('/track-application')
def track_application():
    return render_template('track-application.html')


@app.route('/signup')
def signup():
    if site_setting('registration_enabled','1') != '1': return render_template('message.html', title='Registration unavailable', message='New account registration is currently disabled by the administrator.'), 403
    return render_template('auth.html', mode='signup')

@app.route('/login')
def login():
    return render_template('auth.html', mode='login')

@app.post('/api/auth/signup')
def api_signup():
    if site_setting('registration_enabled','1') != '1': return jsonify({'ok':False,'error':'Registration is disabled.'}),403
    data=request.form; name=data.get('full_name','').strip(); email=data.get('email','').strip().lower(); password=data.get('password',''); phone=data.get('phone','').strip()
    if not name or not email or '@' not in email or len(password)<8: return jsonify({'ok':False,'error':'Enter a name, valid email and password of at least 8 characters.'}),400
    conn=db()
    try:
        cur=conn.execute('INSERT INTO users(full_name,email,password_hash,phone,created_at) VALUES(?,?,?,?,?)',(name,email,generate_password_hash(password),phone,now_iso())); conn.commit(); uid=cur.lastrowid
    except sqlite3.IntegrityError:
        conn.close(); return jsonify({'ok':False,'error':'An account with that email already exists.'}),409
    conn.close(); session['user_id']=uid; return jsonify({'ok':True})

@app.post('/api/auth/login')
def api_login():
    data=request.form; email=data.get('email','').strip().lower(); password=data.get('password','')
    conn=db(); row=conn.execute('SELECT * FROM users WHERE email=?',(email,)).fetchone()
    if not row or not row['is_active'] or not check_password_hash(row['password_hash'],password): conn.close(); return jsonify({'ok':False,'error':'Invalid email/password or account disabled.'}),401
    conn.execute('UPDATE users SET last_login=? WHERE id=?',(now_iso(),row['id'])); conn.commit(); conn.close(); session['user_id']=row['id']; return jsonify({'ok':True})

@app.post('/api/auth/logout')
def api_logout():
    session.pop('user_id',None); return jsonify({'ok':True})

@app.route('/account')
@user_required
def account(): return render_template('account.html')

@app.route('/admin')
def admin():
    return render_template('admin.html')


@app.post('/api/employer')
def create_employer():
    if site_setting('payments_enabled','1') != '1': return jsonify({'ok':False,'error':'Employer payments are currently disabled by the administrator.'}),403
    data = request.form
    required = ['companyName', 'contactName', 'jobTitle', 'email', 'phone', 'country', 'companySize', 'hiringNeeds']
    if any(not data.get(k, '').strip() for k in required):
        return jsonify({'ok': False, 'error': 'Please complete all required fields.'}), 400
    conn = db()
    expires=(datetime.now(timezone.utc)+__import__('datetime').timedelta(minutes=30)).replace(microsecond=0).isoformat()
    cur = conn.execute('''INSERT INTO employer_submissions
      (company_name,contact_name,job_title,email,phone,website,country,company_size,hiring_needs,budget,created_at,payment_expires_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?)''', (
        data['companyName'].strip(), data['contactName'].strip(), data['jobTitle'].strip(),
        data['email'].strip(), data['phone'].strip(), data.get('website', '').strip(), data.get('country', '').strip(),
        data.get('companySize', '').strip(), data['hiringNeeds'].strip(), data.get('budget', '').strip(), now_iso(), expires
    ))
    conn.commit()
    sid = cur.lastrowid
    conn.close()
    return jsonify({'ok': True, 'id': sid})


@app.post('/api/payment')
def submit_payment():
    if site_setting('payments_enabled','1') != '1': return jsonify({'ok':False,'error':'Payments are currently disabled by the administrator.'}),403
    sid = request.form.get('submission_id', '').strip()
    ref = request.form.get('transactionRef', '').strip()
    payer = request.form.get('payerName', '').strip()
    if not sid or not ref or not payer:
        return jsonify({'ok': False, 'error': 'Submission ID, transaction reference and payer name are required.'}), 400
    conn = db()
    sub = conn.execute('SELECT * FROM employer_submissions WHERE id=?', (sid,)).fetchone()
    if not sub:
        conn.close()
        return jsonify({'ok': False, 'error': 'Employer submission not found.'}), 404
    if sub['payment_expires_at']:
        try:
            if datetime.fromisoformat(sub['payment_expires_at']) < datetime.now(timezone.utc):
                conn.close(); return jsonify({'ok':False,'error':'The 30-minute payment window has expired. Please submit a new employer request.'}), 410
        except ValueError:
            pass
    proof = request.files.get('proof')
    filename = ''
    if proof and proof.filename:
        filename = f"{uuid.uuid4().hex}_{secure_filename(proof.filename)}"
        proof.save(os.path.join(UPLOADS, filename))
    cur = conn.execute('''INSERT INTO payments(submission_id,transaction_ref,payer_name,proof_filename,submitted_at,expires_at)
                         VALUES(?,?,?,?,?,?)''', (sid, ref, payer, filename, now_iso(), sub['payment_expires_at']))
    conn.execute("UPDATE employer_submissions SET status='payment_pending' WHERE id=?", (sid,))
    conn.commit()
    pid = cur.lastrowid
    conn.close()
    return jsonify({'ok': True, 'id': pid, 'reference': ref})


@app.post('/api/job-application')
def create_job_application():
    if site_setting('applications_enabled','1') != '1': return jsonify({'ok':False,'error':'Applications are currently disabled by the administrator.'}),403
    data = request.form
    required = ['firstName', 'lastName', 'email', 'phone', 'location', 'jobTitle', 'specialism', 'experience', 'jobType']
    if any(not data.get(k, '').strip() for k in required):
        return jsonify({'ok': False, 'error': 'Please complete all required fields.'}), 400
    cv = request.files.get('cv')
    photo = request.files.get('photo')
    cv_name = photo_name = ''
    if cv and cv.filename:
        cv_name = f"cv_{uuid.uuid4().hex}_{secure_filename(cv.filename)}"
        cv.save(os.path.join(UPLOADS, cv_name))
    if photo and photo.filename:
        photo_name = f"photo_{uuid.uuid4().hex}_{secure_filename(photo.filename)}"
        photo.save(os.path.join(UPLOADS, photo_name))
    conn = db()
    cur = conn.execute('''INSERT INTO job_applications
        (user_id,full_name,email,phone,location,job_title,specialism,experience,job_type,summary,cv_filename,photo_filename,created_at)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)''', (
            session.get('user_id'), f"{data['firstName'].strip()} {data['lastName'].strip()}", data['email'].strip(), data['phone'].strip(),
            data['location'].strip(), data['jobTitle'].strip(), data['specialism'].strip(), data['experience'].strip(),
            data['jobType'].strip(), data.get('summary', '').strip(), cv_name, photo_name, now_iso()
        ))
    application_id = cur.lastrowid
    conn.commit(); conn.close()
    return jsonify({'ok': True, 'application_id': application_id})


@app.get('/api/payment-config')
def payment_config():
    return jsonify({'amount': current_payment_amount(), 'details': PAYMENT_DETAILS})


@app.get('/api/jobs')
def api_jobs():
    q = request.args.get('q', '').strip().lower()
    location = request.args.get('location', '').strip().lower()
    category = request.args.get('category', '').strip().lower()
    conn = db()
    rows = conn.execute('''SELECT id,title,location,category,job_type,available_roles
                           FROM jobs WHERE is_active=1 ORDER BY id DESC''').fetchall()
    conn.close()
    jobs_data = [dict(r) for r in rows if r['available_roles'] > 0]
    if q:
        jobs_data = [j for j in jobs_data if q in j['title'].lower() or q in j['category'].lower()]
    if location:
        jobs_data = [j for j in jobs_data if location in j['location'].lower()]
    if category:
        jobs_data = [j for j in jobs_data if category in j['category'].lower()]
    return jsonify(jobs_data)



@app.post('/api/contact')
def contact_message():
    data=request.form
    name=data.get('name','').strip(); email=data.get('email','').strip(); message=data.get('message','').strip()
    if not name or not email or not message:
        return jsonify({'ok':False,'error':'Name, email and message are required.'}),400
    conn=db(); conn.execute('INSERT INTO contact_messages(name,email,phone,subject,message,created_at) VALUES(?,?,?,?,?,?)',
        (name,email,data.get('phone','').strip(),data.get('subject','').strip(),message,now_iso())); conn.commit(); conn.close()
    return jsonify({'ok':True})

@app.post('/api/newsletter')
def newsletter():
    email=request.form.get('email','').strip().lower()
    if not email or '@' not in email: return jsonify({'ok':False,'error':'Enter a valid email address.'}),400
    conn=db()
    try:
        conn.execute('INSERT INTO newsletter_subscribers(email,created_at) VALUES(?,?)',(email,now_iso())); conn.commit()
    except sqlite3.IntegrityError:
        conn.close(); return jsonify({'ok':False,'error':'This email is already subscribed.'}),409
    conn.close(); return jsonify({'ok':True})

@app.get('/api/application/mine')
@user_required
def application_mine():
    conn=db(); rows=conn.execute('SELECT id,job_title,location,created_at,status FROM job_applications WHERE user_id=? ORDER BY id DESC',(session['user_id'],)).fetchall(); conn.close(); return jsonify({'applications':[dict(r) for r in rows]})

@app.get('/api/application/<int:application_id>')
def application_status(application_id):
    conn=db(); row=conn.execute('SELECT id,full_name,email,job_title,location,created_at,status FROM job_applications WHERE id=?',(application_id,)).fetchone(); conn.close()
    if not row: return jsonify({'ok':False,'error':'Application not found.'}),404
    return jsonify({'ok':True,'application':dict(row)})

@app.patch('/api/admin/users/<int:user_id>')
@admin_required
def admin_user_update(user_id):
    data=request.get_json(silent=True) or {}; active=1 if data.get('is_active') else 0
    conn=db(); conn.execute('UPDATE users SET is_active=? WHERE id=?',(active,user_id)); conn.commit(); conn.close(); return jsonify({'ok':True})

@app.patch('/api/admin/settings')
@admin_required
def admin_settings_update():
    data=request.get_json(silent=True) or {}; allowed=['registration_enabled','applications_enabled','payments_enabled','maintenance_mode','payment_amount']
    conn=db()
    for key in allowed:
        if key in data:
            if key == 'payment_amount':
                value = str(data[key]).strip().replace(',', '')
                try:
                    if float(value) < 0: raise ValueError
                    value = f'{float(value):.2f}'
                except (TypeError, ValueError):
                    conn.close(); return jsonify({'ok':False,'error':'Payment amount must be a valid non-negative number.'}),400
            else:
                value = '1' if data[key] else '0'
            conn.execute('INSERT INTO site_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',(key,value))
    conn.commit(); conn.close(); return jsonify({'ok':True})

@app.post('/api/admin/logo')
@admin_required
def admin_logo_upload():
    f=request.files.get('logo')
    if not f or not f.filename: return jsonify({'ok':False,'error':'Choose a logo image.'}),400
    ext=os.path.splitext(secure_filename(f.filename))[1].lower() or '.png'
    filename=f'uploaded-logo-{uuid.uuid4().hex}{ext}'; f.save(os.path.join(STATIC_IMAGES,filename)); path=url_for('static',filename='images/'+filename)
    conn=db(); conn.execute('INSERT INTO site_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value',('site_logo',path)); conn.commit(); conn.close(); return jsonify({'ok':True,'path':path})

@app.post('/api/admin/testimonials')
@admin_required
def admin_testimonial_create():
    data=request.form; name=data.get('name','').strip(); quote=data.get('quote','').strip(); role=data.get('role','').strip(); rating=max(1,min(5,int(data.get('rating','5') or 5)))
    if not name or not quote: return jsonify({'ok':False,'error':'Name and review are required.'}),400
    f=request.files.get('image'); filename=''
    if f and f.filename:
        filename=f'testimonial-{uuid.uuid4().hex}_{secure_filename(f.filename)}'; f.save(os.path.join(STATIC_IMAGES,filename))
    conn=db(); cur=conn.execute('INSERT INTO testimonials(name,role,rating,quote,image_filename,created_at) VALUES(?,?,?,?,?,?)',(name,role,rating,quote,filename,now_iso())); conn.commit(); tid=cur.lastrowid; conn.close(); return jsonify({'ok':True,'id':tid})

@app.delete('/api/admin/testimonials/<int:testimonial_id>')
@admin_required
def admin_testimonial_delete(testimonial_id):
    conn=db(); conn.execute('DELETE FROM testimonials WHERE id=?',(testimonial_id,)); conn.commit(); conn.close(); return jsonify({'ok':True})

@app.post('/api/admin/login')
def admin_login():
    payload = request.get_json(silent=True) or {}
    if payload.get('password', '') == ADMIN_PASSWORD:
        session['admin_logged_in'] = True
        return jsonify({'ok': True})
    return jsonify({'ok': False, 'error': 'Incorrect password.'}), 401


@app.post('/api/admin/logout')
def admin_logout():
    session.pop('admin_logged_in', None)
    return jsonify({'ok': True})


@app.get('/api/admin/status')
def admin_status():
    return jsonify({'logged_in': bool(session.get('admin_logged_in'))})


@app.get('/api/admin/dashboard')
@admin_required
def admin_dashboard():
    conn = db()
    payments = conn.execute('''SELECT p.*, s.company_name,s.contact_name,s.email,s.phone,s.hiring_needs,s.status AS submission_status
        FROM payments p JOIN employer_submissions s ON s.id=p.submission_id ORDER BY p.id DESC''').fetchall()
    jobs_rows = conn.execute('SELECT * FROM jobs ORDER BY id DESC').fetchall()
    apps = conn.execute('SELECT * FROM job_applications ORDER BY id DESC LIMIT 50').fetchall()
    messages = conn.execute('SELECT * FROM contact_messages ORDER BY id DESC LIMIT 50').fetchall()
    subscribers = conn.execute('SELECT * FROM newsletter_subscribers ORDER BY id DESC LIMIT 50').fetchall()
    users = conn.execute('SELECT id,full_name,email,phone,is_active,created_at,last_login FROM users ORDER BY id DESC LIMIT 100').fetchall()
    testimonials = conn.execute('SELECT * FROM testimonials ORDER BY id DESC').fetchall()
    stats = {
        'jobs': conn.execute('SELECT COUNT(*) FROM jobs WHERE is_active=1').fetchone()[0],
        'available_roles': conn.execute('SELECT COALESCE(SUM(available_roles),0) FROM jobs WHERE is_active=1').fetchone()[0],
        'pending_payments': conn.execute("SELECT COUNT(*) FROM payments WHERE status='pending'").fetchone()[0],
        'job_applications': conn.execute('SELECT COUNT(*) FROM job_applications').fetchone()[0],
        'contact_messages': conn.execute("SELECT COUNT(*) FROM contact_messages WHERE status='new'").fetchone()[0],
        'subscribers': conn.execute('SELECT COUNT(*) FROM newsletter_subscribers').fetchone()[0],
        'users': conn.execute('SELECT COUNT(*) FROM users').fetchone()[0],
    }
    conn.close()
    settings = {k: site_setting(k) for k in ['registration_enabled','applications_enabled','payments_enabled','maintenance_mode','payment_amount','site_logo']}
    return jsonify({'stats': stats, 'settings': settings, 'users': [dict(r) for r in users], 'testimonials': [dict(r) for r in testimonials], 'payments': [dict(r) for r in payments], 'jobs': [dict(r) for r in jobs_rows], 'applications': [dict(r) for r in apps], 'messages':[dict(r) for r in messages], 'subscribers':[dict(r) for r in subscribers]})


@app.post('/api/admin/jobs')
@admin_required
def create_job_admin():
    data = request.get_json(silent=True) or {}
    title = str(data.get('title', '')).strip()
    location = str(data.get('location', '')).strip()
    category = str(data.get('category', '')).strip()
    job_type = str(data.get('job_type', '')).strip()
    try:
        available = max(0, int(data.get('available_roles', 0)))
    except (TypeError, ValueError):
        return jsonify({'ok': False, 'error': 'Available roles must be a whole number.'}), 400
    if not all([title, location, category, job_type]):
        return jsonify({'ok': False, 'error': 'Title, location, category and job type are required.'}), 400
    conn = db()
    cur = conn.execute('''INSERT INTO jobs(title,location,category,job_type,available_roles,is_active,created_at,updated_at)
                          VALUES(?,?,?,?,?,?,?,?)''', (title, location, category, job_type, available, 1, now_iso(), now_iso()))
    conn.commit(); jid = cur.lastrowid; conn.close()
    return jsonify({'ok': True, 'id': jid})


@app.patch('/api/admin/jobs/<int:job_id>')
@admin_required
def update_job_admin(job_id):
    data = request.get_json(silent=True) or {}
    allowed = ['title', 'location', 'category', 'job_type']
    fields, values = [], []
    for key in allowed:
        if key in data:
            value = str(data[key]).strip()
            if not value:
                return jsonify({'ok': False, 'error': f'{key} cannot be empty.'}), 400
            fields.append(f'{key}=?'); values.append(value)
    if 'available_roles' in data:
        try:
            available = max(0, int(data['available_roles']))
        except (TypeError, ValueError):
            return jsonify({'ok': False, 'error': 'Available roles must be a whole number.'}), 400
        fields.append('available_roles=?'); values.append(available)
    if 'is_active' in data:
        fields.append('is_active=?'); values.append(1 if data['is_active'] else 0)
    if not fields:
        return jsonify({'ok': False, 'error': 'No changes supplied.'}), 400
    fields.append('updated_at=?'); values.append(now_iso()); values.append(job_id)
    conn = db()
    cur = conn.execute(f"UPDATE jobs SET {','.join(fields)} WHERE id=?", values)
    conn.commit(); conn.close()
    if cur.rowcount == 0:
        return jsonify({'ok': False, 'error': 'Job not found.'}), 404
    return jsonify({'ok': True})


@app.delete('/api/admin/jobs/<int:job_id>')
@admin_required
def delete_job_admin(job_id):
    conn = db()
    conn.execute('UPDATE jobs SET is_active=0, available_roles=0, updated_at=? WHERE id=?', (now_iso(), job_id))
    conn.commit(); conn.close()
    return jsonify({'ok': True})


@app.post('/api/admin/payments/<int:pid>/verify')
@admin_required
def verify_payment(pid):
    conn = db(); row = conn.execute('SELECT * FROM payments WHERE id=?', (pid,)).fetchone()
    if not row:
        conn.close(); return jsonify({'ok': False, 'error': 'Payment not found'}), 404
    conn.execute("UPDATE payments SET status='verified',verified_at=?,admin_note=NULL WHERE id=?", (now_iso(), pid))
    conn.execute("UPDATE employer_submissions SET status='verified' WHERE id=?", (row['submission_id'],))
    conn.commit(); conn.close()
    return jsonify({'ok': True})


@app.post('/api/admin/payments/<int:pid>/reject')
@admin_required
def reject_payment(pid):
    note = str((request.get_json(silent=True) or {}).get('note', 'Payment could not be verified.')).strip()
    conn = db(); row = conn.execute('SELECT * FROM payments WHERE id=?', (pid,)).fetchone()
    if not row:
        conn.close(); return jsonify({'ok': False, 'error': 'Payment not found'}), 404
    conn.execute("UPDATE payments SET status='rejected',admin_note=? WHERE id=?", (note, pid))
    conn.execute("UPDATE employer_submissions SET status='payment_rejected' WHERE id=?", (row['submission_id'],))
    conn.commit(); conn.close()
    return jsonify({'ok': True})


@app.patch('/api/admin/applications/<int:aid>')
@admin_required
def update_application(aid):
    data=request.get_json(silent=True) or {}
    status=data.get('status','new')
    if status not in {'new','reviewing','shortlisted','interview','placed','rejected'}:
        return jsonify({'ok':False,'error':'Invalid application status.'}),400
    conn=db(); cur=conn.execute('UPDATE job_applications SET status=? WHERE id=?',(status,aid)); conn.commit(); conn.close()
    if cur.rowcount==0: return jsonify({'ok':False,'error':'Application not found.'}),404
    return jsonify({'ok':True})

@app.get('/uploads/<path:name>')
@admin_required
def uploads(name):
    return send_from_directory(UPLOADS, name, as_attachment=True)


init_db()

if __name__ == '__main__':
    app.run(debug=True)
