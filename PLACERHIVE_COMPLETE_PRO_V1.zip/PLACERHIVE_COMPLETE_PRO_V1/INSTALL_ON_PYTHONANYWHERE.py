from pathlib import Path
from datetime import datetime
import shutil

HOME = Path.home()
CURRENT = HOME / 'placerhive-site'
PACKAGE = Path(__file__).resolve().parent / 'placerhive-site'
STAMP = datetime.now().strftime('%Y%m%d-%H%M%S')
BACKUP = HOME / f'placerhive-site-before-pro-{STAMP}'

if not PACKAGE.exists():
    raise SystemExit(f'Package folder not found: {PACKAGE}')

# Back up only code/content that this upgrade will replace.
if CURRENT.exists():
    BACKUP.mkdir(parents=True, exist_ok=False)
    for name in ['app.py', 'requirements.txt', 'README_PYTHONANYWHERE.txt']:
        src = CURRENT / name
        if src.exists(): shutil.copy2(src, BACKUP / name)
    for name in ['templates', 'static']:
        src = CURRENT / name
        if src.exists(): shutil.copytree(src, BACKUP / name)

    # Preserve the live database and uploads in the new codebase.
    for name in ['placerhive.db', 'uploads']:
        src = CURRENT / name
        dst = PACKAGE / name
        if src.exists() and not dst.exists():
            if src.is_dir(): shutil.copytree(src, dst)
            else: shutil.copy2(src, dst)

# Copy package files over the live site without touching venv or other unrelated files.
CURRENT.mkdir(parents=True, exist_ok=True)
for item in PACKAGE.iterdir():
    if item.name in {'placerhive.db', 'uploads', 'venv', '.git'}:
        continue
    target = CURRENT / item.name
    if item.is_dir():
        if target.exists(): shutil.rmtree(target)
        shutil.copytree(item, target)
    else:
        shutil.copy2(item, target)

print('PLACERHIVE COMPLETE PRO V1 installed successfully.')
print(f'Backup created: {BACKUP if BACKUP.exists() else "No previous site was found"}')
print(f'Live site: {CURRENT}')
print('Database preserved: YES')
print('Uploads preserved: YES')
print('Next: reload the PythonAnywhere web app and open /admin.')
